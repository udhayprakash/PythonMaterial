Function without arguments 

Function with arguments 

Function with arguments and return
    
        return values unpacking

Function Overwriting 

Default Arguments

    mutable default arguments and meory leakage

Variadic Functions 
    
        variable Arguments 

        variable keyword arguments

Variable Scoping: Global & Local 

Recursions
    
    controlled recursions
    infinite recursions
    Mutually recursions

Lambdas

Higher-Order Functions

    zip
    map
    filter
    itertools.reduce


Partial Functions 

Inner Functions 

Closures

Decorators 
