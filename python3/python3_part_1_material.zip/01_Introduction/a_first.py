num1 = 123
num2 = 345

num1
print('num1')
print(num1)

print('num1', num1, 34, 5, 666)
print('num1      =', num1)
print('type(num1)=', type(num1))


# Python is a dynamically typed language 
num1 = -3.1416 
print('num1      =', num1, type(num1))


num1 = '-3.1416' 
print('num1      =', num1, type(num1))

num1 = "three" 
print('num1      =', num1, type(num1))

num1 = True 
print('num1      =', num1, type(num1))

num1 = None 
print('num1      =', num1, type(num1))