#!/usr/bin/python
"""
purpose: comment operator

python  is interpreter based language
- means each line executes separately
    unless it is a block of code 
     - if elif while function class

"""

print('Hello World1')#hjh

print('Hello ' 'World2')#,

print('Hello ')  # 'World3'

print()  # 'Hello ' #'World4'

print()

print('Hello  #World5')

# print #'Hello ' #'World6'

# sldkjlkdj;wl kf'w;  dp'kwf';e kr'!@#$%^&*()

'''
Used to handle multi-line strings
or 
in cases where multiple single and double quotes are present in string
'''

"""
used for 
docstrings

print 'Hello World7'
"""
