num1 = 12
num2 = 34
