
numbers = range(99)

import pdb; pdb.set_trace()
# breakpoint()
for each_num in numbers:
    if each_num % 2 != 0:
        print(each_num, end=',')

