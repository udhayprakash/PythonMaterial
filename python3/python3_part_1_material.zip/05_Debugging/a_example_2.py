#!/usr/bin/python
import pdb
pdb.set_trace()

for i in range(1,11):
  if i == 5:
    continue
  print(i)
