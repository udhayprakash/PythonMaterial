#!/usr/bin/python
import pdb
pdb.set_trace()

for i in (1,2,3,4,5,6,7):
  print(i)
