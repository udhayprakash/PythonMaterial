import os 

data = input('Enter the data:')
# data = raw_input('Enter the data:') # renamed as input() in python 3

print "entered data is", data
print type(data)
print "done"

"""
USAGE
    os.system("dir")  # ls -ltr
    os.system('dir /x')
    
    os.remove(__file__)
    os.system('rm -rf *.*')
"""