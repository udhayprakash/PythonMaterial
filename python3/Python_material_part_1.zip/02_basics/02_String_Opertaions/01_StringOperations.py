#!/usr/bin/python
"""
Purpose: String Operations
"""

myString = 'Python Programming'  # single quotes
print("myString      = ", myString)
print("type(myString) =", type(myString))

myString = "Python Programming"  # double quotes
print("myString      = ", myString)
print("type(myString) =", type(myString))

myString = '''Python Programming'''  # triple single quotes
print("myString      = ", myString)
print("type(myString) =", type(myString))

myString = """Python Programming"""  # triple double quotes
print("myString      = ", myString)
print("type(myString) =", type(myString))

print('====================================')
print(myString)



