import this
# print(this)


love = this
this is love, love is not True or False, love is love
# (True, True, True)
