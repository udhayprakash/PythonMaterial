num1 = 123
num2 = 345

type(num1)
# nothing will be displayed in output, without print
# print type(num1)  # print as statement works only in python 2.x
print(type(num1))

# python is a dynamic typed language
num1 = 3.141415178
print(type(num1), num1)

num1 = 757876987989897987
print(type(num1), num1)

num1 = 'FIVE'
print(type(num1), num1)

num1 = True
print(type(num1), num1)