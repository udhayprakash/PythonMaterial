#!/usr/bin/python
"""
Purpose: Multiple statements in same line

; statement completion operator
, logic separator
"""


num1 = 123;
num2 = 456

sumOfNumbers = num1 + num2

print('Sum of Numbers:', sumOfNumbers)

#################################################

num1 = 123; num2 = 456; sumOfNumbers = num1 + num2; print('Sum of Numbers:', sumOfNumbers)

"""
python -c "num1 = 123; num2 = 456; sumOfNumbers = num1 + num2; print('Sum of Numbers:', sumOfNumbers)"


scripting language
    - batch script
    - shell script
"""
