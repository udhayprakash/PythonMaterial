#!/usr/bin/python

"""     
Purpose: This is a demonstration script
first line is shebang line
"""
__name__ = 'author name'
__version__ = '0.1'

# # print as a statement- py 2
# print "Hello World!"
# print 123

# print as a function - py 2 & 3
print("Hello World!")
print(123)
