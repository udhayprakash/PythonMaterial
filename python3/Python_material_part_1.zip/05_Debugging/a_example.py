# import pdb

my_sentence = 'Today is an interesting day for learning python'
print(my_sentence)

# pdb.set_trace()
# breakpoint()

for each_char in my_sentence:
    print(each_char)


# pydevd



usd = 73
cand = 50

print("usd < cand ", usd  < cand)
print("70 < 49", 70 < 49)
print("70 > 49", 70 > 49)

print("89 >= 49", 89 >= 49)
print("89 <= 49", 89 <= 49)

print("89 == 89", 89 == 89)  # dont confuse with = (assignment Operator)
# print "89 = 89", 89 = 89   Syntax Error



for each_char in my_sentence:
    print(each_char)
