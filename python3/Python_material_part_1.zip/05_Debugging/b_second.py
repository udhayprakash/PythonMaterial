#!/usr/bin/python
# second.py
import pdb
pdb.set_trace()
import first as f
print f.hello()
print f.add(10,20)
print f.version
