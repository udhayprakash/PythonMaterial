#!/usr/bin/python
# third.py
import pdb

for i in (1,2,3,4,5,6,7):
  pdb.set_trace()
  print i

