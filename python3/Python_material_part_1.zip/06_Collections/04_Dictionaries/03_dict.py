
sentence = '''Python is a wonderful language. we can solve any 
computational problem with this'''

'''
P -23
a - 34
 - 10 

character frequency analyses  - case sensitive
word frequency analyses   - case insensitive
'''