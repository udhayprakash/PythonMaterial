search_query = 'site:linkedin.com/in/ AND "python developer" AND "London"'
file_name = 'results_file.csv'

linkedin_username = ''
linkedin_password = ''
